clear all

use "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\5-gd\gd_2020_2024.dta"

keep if gd==0

merge 1:1 countyid year using "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\1-totalbirths\total_births_2020_2024gd.dta"

drop _merge

drop gd

gen gd=births-gd_births

gen gd_rate=gd/births*1000

save "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\5-gd\merged_gd-births20202024.dta", replace



