clear all

use "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\7-pre\pre_2020_2024.dta"

keep if pre==0

merge 1:1 countyid year using "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\1-totalbirths\total_births_2020_2024pre.dta"

drop _merge

drop pre

gen pre=births-pre_births

gen pre_rate=pre/births*1000

save "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\7-pre\merged_pre-births20202024.dta", replace



