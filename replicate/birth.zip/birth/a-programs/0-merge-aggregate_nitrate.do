clear all

import delimited "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\mn-nitrate-clean.csv"

merge m:1 geoid using "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\mn-pwsid-county.dta"

keep if _merge==3

rename county residencecounty

* Make sure variables are numeric
destring nitrate population, replace force

* Population-weighted nitrate contribution
gen nitrate_pop = nitrate * population

* Collapse water systems to county-year
collapse ///
    (sum) nitrate_pop population ///
    (mean) nitrate_unweighted = nitrate ///
    (max) nitrate_max = nitrate ///
    (count) n_systems = nitrate, ///
    by(residencecounty year)

* Population-weighted mean nitrate
gen nitrate = nitrate_pop / population

drop nitrate_pop

label var nitrate "Population-weighted mean nitrate (mg/L)"
label var nitrate_unweighted "Unweighted mean nitrate (mg/L)"
label var nitrate_max "Maximum system nitrate (mg/L)"
label var population "Population served by community water systems"
label var n_systems "Number of community water systems"

order residencecounty year nitrate population ///
      nitrate_unweighted nitrate_max n_systems

sort residencecounty year

* Confirm exactly one observation per county-year
isid residencecounty year

save "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\mn-aggregate-nitrate.dta", replace