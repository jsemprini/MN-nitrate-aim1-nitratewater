clear all

cd "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\1-totalbirths"

foreach n of numlist 0 1 2 3 4 {

    import delimited ///
    "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\202`n' Annual Summary Birth Data Table.csv", clear

    drop if countyid == -999

    keep if variables1 == "Maternal Gestational Diabetes" & variables2 == "Infant Sex"

    collapse (sum) births = count, by(countyid residencecounty)

    drop if countyid == .

    gen year = 2020 + `n'

    save total_202`n'.dta, replace
}

* Append all annual files
use total_2020.dta, clear

foreach n of numlist 1 2 3 4 {
    append using total_202`n'.dta
}

order countyid residencecounty year births
sort countyid year

save total_births_2020_2024gd.dta, replace