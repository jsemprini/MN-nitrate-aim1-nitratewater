clear all

cd "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\6-gh"

foreach n of numlist 0 1 2 3 4 {

    import delimited ///
    "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\202`n' Annual Summary Birth Data Table.csv", clear

    drop if countyid == -999

    keep if variables1 == "Maternal Gestational Hypertension" & variables2 == "Infant Sex"

    gen gh = 1
    replace gh = 0 if values1 == "No" | values1 == "Unknown"

    collapse (sum) gh_births = count, by(countyid residencecounty gh)

    drop if countyid == .

    gen year = 2020 + `n'

    save gh_202`n'.dta, replace
}

* Append all years
use gh_2020.dta, clear

foreach n of numlist 1 2 3 4 {
    append using gh_202`n'.dta
}

order countyid residencecounty year gh gh_births
sort countyid year gh

save gh_2020_2024.dta, replace