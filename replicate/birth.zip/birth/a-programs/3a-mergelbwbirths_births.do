clear all

use "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\3-lowbirthweight\lbw_2020_2024.dta"

keep if lbw==0

merge 1:1 countyid year using "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\1-totalbirths\total_births_2020_2024lbw.dta"

drop _merge

drop lbw

gen lbw=births-lbw_births

gen lbw_rate=lbw/births*1000

save "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\3-lowbirthweight\merged_lbw-births20202024.dta", replace



