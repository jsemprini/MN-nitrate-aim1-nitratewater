clear all

use  "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\6-gh\merged_gh-births-nitrate-2019-2024.dta"

egen id=group(residencecounty)

xtset id year

cd "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\b-results"

log using 5-gh_analysis.log , replace

sum gh_rate, det

xtreg gh_rate L1.nitrate i.year, fe vce(cluster id)

margins , dydx(L1.nitrate)
margins , dyex(L1.nitrate)
margins , eydx(L1.nitrate)
margins , eyex(L1.nitrate)

log close



