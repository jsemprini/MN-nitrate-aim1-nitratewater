clear all

cd "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\3-lowbirthweight"

foreach n of numlist 0 1 2 3 4 {

    import delimited ///
    "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\202`n' Annual Summary Birth Data Table.csv", clear

    drop if countyid == -999

    keep if variables1 == "Low Birth Weight" & variables2 == "Infant Sex"

    gen lbw = 1
    replace lbw = 0 if values1 == "No" | values1 == "Unknown"

    collapse (sum) lbw_births = count, by(countyid residencecounty lbw)

    drop if countyid == .

    gen year = 2020 + `n'

    save lbw_202`n'.dta, replace
}

* Append all years
use lbw_2020.dta, clear

foreach n of numlist 1 2 3 4 {
    append using lbw_202`n'.dta
}

order countyid residencecounty year lbw lbw_births
sort countyid year lbw

save lbw_2020_2024.dta, replace