clear all

use "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\2-pretermbirths\ptb_2020_2024.dta"

keep if pt==0

merge 1:1 countyid year using "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\1-totalbirths\total_births_2020_2024.dta"

drop _merge

gen ptb=births-pt_births

gen ptb_rate=ptb/births*1000

save "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\2-pretermbirths\merged_ptb-births20202024.dta", replace



