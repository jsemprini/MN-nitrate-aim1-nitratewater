clear all

cd "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\4-nicu"

foreach n of numlist 0 1 2 3 4 {

    import delimited ///
    "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\202`n' Annual Summary Birth Data Table.csv", clear

    drop if countyid == -999

    keep if variables1 == "NICU Admission" & variables2 == "Infant Sex"

    gen nicu = 1
    replace nicu = 0 if values1 == "No" | values1 == "Unknown"

    collapse (sum) nicu_births = count, by(countyid residencecounty nicu)

    drop if countyid == .

    gen year = 2020 + `n'

    save nicu_202`n'.dta, replace
}

* Append all years
use nicu_2020.dta, clear

foreach n of numlist 1 2 3 4 {
    append using nicu_202`n'.dta
}

order countyid residencecounty year nicu nicu_births
sort countyid year nicu

save nicu_2020_2024.dta, replace