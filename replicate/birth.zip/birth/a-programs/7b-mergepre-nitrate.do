clear all

use "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\mn-aggregate-nitrate.dta"

merge 1:1 residencecounty year using "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\7-pre\merged_pre-births20202024.dta"
tab year _merge
tab county if _merge==2

drop if _merge==2

save "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\7-pre\merged_pre-births-nitrate-2019-2024.dta", replace