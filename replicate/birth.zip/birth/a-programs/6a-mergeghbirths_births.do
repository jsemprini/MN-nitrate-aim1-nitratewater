clear all

use "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\6-gh\gh_2020_2024.dta"

keep if gh==0

merge 1:1 countyid year using "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\1-totalbirths\total_births_2020_2024gh.dta"

drop _merge

drop gh

gen gh=births-gh_births

gen gh_rate=gh/births*1000

save "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\6-gh\merged_gh-births20202024.dta", replace



