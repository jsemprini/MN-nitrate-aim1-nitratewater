clear all

use  "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\2-pretermbirths\merged_ptb-births-nitrate-2019-2024.dta"

egen id=group(residencecounty)

xtset id year

cd "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\b-results"

log using ptb_analysis.log , replace

sum nitrate , det

sum ptb_rate, det

xtreg ptb_rate L1.nitrate i.year, fe vce(cluster id)

margins , dydx(L1.nitrate)
margins , dyex(L1.nitrate)
margins , eydx(L1.nitrate)
margins , eyex(L1.nitrate)

log close



