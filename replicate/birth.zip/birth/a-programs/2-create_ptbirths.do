clear all

cd "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\2-pretermbirths"

foreach n of numlist 0 1 2 3 4 {

    import delimited ///
    "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\202`n' Annual Summary Birth Data Table.csv", clear

    drop if countyid == -999

    keep if variables1 == "Premature Births" & variables2 == "Infant Sex"

    gen pt = 1
    replace pt = 0 if values1 == "No" | values1 == "Unknown"

    collapse (sum) pt_births = count, by(countyid residencecounty pt)

    drop if countyid == .

    gen year = 2020 + `n'

    save ptb_202`n'.dta, replace
}

* Append all years
use ptb_2020.dta, clear

foreach n of numlist 1 2 3 4 {
    append using ptb_202`n'.dta
}

order countyid residencecounty year pt pt_births
sort countyid year pt

save ptb_2020_2024.dta, replace