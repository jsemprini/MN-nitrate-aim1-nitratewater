clear all

use  "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\7-pre\merged_pre-births-nitrate-2019-2024.dta"

egen id=group(residencecounty)

xtset id year

cd "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\b-results"

log using 6-pre_analysis.log , replace

sum pre_rate, det

xtreg pre_rate L1.nitrate i.year, fe vce(cluster id)

margins , dydx(L1.nitrate)
margins , dyex(L1.nitrate)

log close



