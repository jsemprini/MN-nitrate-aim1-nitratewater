clear all

cd "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\5-gd"

foreach n of numlist 0 1 2 3 4 {

    import delimited ///
    "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\202`n' Annual Summary Birth Data Table.csv", clear

    drop if countyid == -999

    keep if variables1 == "Maternal Gestational Diabetes" & variables2 == "Infant Sex"

    gen gd = 1
    replace gd = 0 if values1 == "No" | values1 == "Unknown"

    collapse (sum) gd_births = count, by(countyid residencecounty gd)

    drop if countyid == .

    gen year = 2020 + `n'

    save gd_202`n'.dta, replace
}

* Append all years
use gd_2020.dta, clear

foreach n of numlist 1 2 3 4 {
    append using gd_202`n'.dta
}

order countyid residencecounty year gd gd_births
sort countyid year gd

save gd_2020_2024.dta, replace