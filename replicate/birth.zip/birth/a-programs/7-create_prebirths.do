clear all

cd "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\7-pre"

foreach n of numlist 0 1 2 3 4 {

    import delimited ///
    "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\202`n' Annual Summary Birth Data Table.csv", clear

    drop if countyid == -999

    keep if variables1 == "Maternal Eclampsia" & variables2 == "Infant Sex"

    gen pre = 1
    replace pre = 0 if values1 == "No" | values1 == "Unknown"

    collapse (sum) pre_births = count, by(countyid residencecounty pre)

    drop if countyid == .

    gen year = 2020 + `n'

    save pre_202`n'.dta, replace
}

* Append all years
use pre_2020.dta, clear

foreach n of numlist 1 2 3 4 {
    append using pre_202`n'.dta
}

order countyid residencecounty year pre pre_births
sort countyid year pre

save pre_2020_2024.dta, replace