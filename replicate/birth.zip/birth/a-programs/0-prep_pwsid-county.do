clear all

import delimited "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\mn-pwsid-county.csv", varnames(1)

save "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\mn-pwsid-county.dta", replace