clear all

use "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\4-nicu\nicu_2020_2024.dta"

keep if nicu==0

merge 1:1 countyid year using "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\1-totalbirths\total_births_2020_2024nicu.dta"

drop _merge

drop nicu

gen nicu=births-nicu_births

gen nicu_rate=nicu/births*1000

save "C:\Users\jsemprini\OneDrive - Des Moines University\2-External-Collab\10-FRDC\1-Birth\3-lowbirthweight\merged_nicu-births20202024.dta", replace



